==================================================
   NanoJS v1.0.0 - Windows Release Package
==================================================

How to run on Windows:
1. If using prebuilt binary:
   Run: nanojs.exe <your-file.mjs>

2. Building from source with MinGW / GCC:
   g++ -std=c++17 -O3 -Iinclude src/*.cpp src/runtime/*.cpp -o nanojs.exe -lws2_32

3. Or with CMake:
   cmake -B build
   cmake --build build --config Release

For full documentation and examples:
https://github.com/priyanshugaurav/NanoJS
