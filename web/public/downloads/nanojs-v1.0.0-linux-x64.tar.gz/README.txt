==================================================
   NanoJS v1.0.0 - Linux Release Package
==================================================

How to run on Linux:
1. If using prebuilt binary:
   chmod +x nanojs
   ./nanojs <your-file.mjs>

2. Building from source with GCC / Clang:
   g++ -std=c++17 -O3 -Iinclude src/*.cpp src/runtime/*.cpp -o nanojs

3. Move to global path:
   sudo mv nanojs /usr/local/bin/

For full documentation and examples:
https://github.com/priyanshugaurav/NanoJS
